/*
 Name : Santosh Ramesh Sunagad
 Description: A15 - Implement a left scrolling number marquee
 Output Requirements:

1. As soon as the board is powered up or reset, a static message (hardcoded) should start scrolling from right to left on SSD.
2. The scroll should repeat indefinitely.
3. The scroll frequency should be 0.5Hz (Approximately, Non Timer Based).

Inputs:
Static number message in code (10 digit number + 2 spaces)

 */
#include <xc.h>
#include "main.h"
#include "ssd_display.h"
/* Charater Array's */
static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE, BLANK, BLANK};

void init_config(void) {
    init_ssd_control(); /* Function call init_config SSD */
}

void main(void) {
    init_config(); /* Function call */
    unsigned int wait = 0;
    unsigned int i = 0, j = 1, k = 2, l = 3;
    while (1) {
        /* Non Blocking Delay */
        if (wait++ == 50) {
            wait = 0;

            ssd[0] = digit[i++];
            ssd[1] = digit[j++];
            ssd[2] = digit[k++];
            ssd[3] = digit[l++];

            if (l == 12)
                l = 0;
            else if (k == 12)
                k = 0;
            else if (j == 12)
                j = 0;
            else if (i == 12)
                i = 0;
        }
        display(ssd);   /* Function call */
    }
}
