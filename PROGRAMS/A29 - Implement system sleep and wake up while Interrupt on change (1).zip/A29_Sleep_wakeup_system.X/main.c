/*
Name : Santosh  Ramesh Sunagad
Description : A29 - Implement system sleep and wake up while Interrupt on change
Output Requirements:

1. As soon as the board is powered up or reset, a message (say 1234) should be displayed in SSD.
2. A LED is toggled  every second.
3. System should go into sleep mode if no activity is detected.
4. System should wake up from sleep on detecting interrupt key.

Inputs:
1. INT0 as Interrupt to wake.

*/
#include <xc.h>
#include "external_interrupt.h"
#include "isr.h"
#include "digital_keypad.h"
#include "ssd_display.h"

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};

unsigned int wait=0;


static void init_config(void) {
    PEIE = 1;
    ADCON1 = 0x0F;

    TRISB6 = 0;
    TRISB0 = 1;

    init_external_interrupt();
    init_ssd_control();
    init_digital_keypad();

    GIE = 1;
}

void main(void) {
    unsigned char key, delay=0;
    init_config();

    while (1) {
        key = read_digital_keypad(STATE_CHANGE);
        if (wait++ == 600) {
            SLEEP();
        } 
        if (key == SWITCH1 || key == SWITCH2 || key ==SWITCH3 || key == SWITCH4) {
            wait = 0;
        }
        
        if (delay++ == 50) {
            delay = 0;
            PORTBbits.RB6 = !PORTBbits.RB6;
        }
        ssd[0] = digit[1];
        ssd[1] = digit[2];
        ssd[2] = digit[3];
        ssd[3] = digit[4];

        display(ssd);
    }
}







