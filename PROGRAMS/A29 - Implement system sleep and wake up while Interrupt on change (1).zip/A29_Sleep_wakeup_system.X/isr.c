#include <xc.h>
#include "isr.h"

extern unsigned int wait;

void __interrupt() isr(void)
{
	if (INT0F == 1)
	{
		wait=0;

		INT0F = 0;
	}
}
