/*
Name : Santosh Ramesh Sunagad
Description : A24 - Implement a 8 field password access to screen

Output Requirements:
1. As soon as the board is powered up or reset, CLCD display the title in the first line.
2. In second line, an ‘_’ (underscore) should blink at rate of 0.5Hz to display the password entry which is indicated as ‘*’ (star).
3. Combination of Key1 and Key2 has to be used as a password.
4. You should provide a max if 5 chances to unlock the system.
5. On every wrong entry an LED should blink constant rate
6. The rate of blink doubles on every failure attempt.
7. On the fifth failure attempt the LED should glow constant and a message has to be put on screen indicating failure.
8. You have to reset the board to retry.
9. On a successful attempt the Embedded message should be displayed on screen.

Inputs:
1. MKS1 and MKS2 as Password Keys.

*/

#include <xc.h>
#include "main.h"
#include "matrix_keypad.h"
#include "clcd.h"

void init_config(void) {
    init_matrix_keypad();
    init_clcd();
    LED1 = 0;
}

void main(void) {
    init_config();
    unsigned char key;
    unsigned int wait = 0, delay = 11000;
    static int flag = 0, chance = 5, start = 1, count = 0, i = 0, once = 1;
    static char arr[8], pass[8] = {0, 0, 0, 0, 1, 1, 1, 1};

    while (1) {
        if (start) {
            key = read_switches(STATE_CHANGE);
            if (key == 1) {
                arr[i] = 0;
                clcd_putch('*', LINE2(i));
                if (arr[i] == pass[i]) {
                    count++;
                }
                i++;
            }
            if (key == 2) {
                arr[i] = 1;
                clcd_putch('*', LINE2(i));
                if (arr[i] == pass[i]) {
                    count++;
                }
                i++;
            }

        }
        if (i == 8 && i == count) {
            start = 0;
            LED1 = 0;
            DISP_ON_AND_CURSOR_OFF;
            clcd_print("Excellent! You", LINE1(1));
            clcd_print("Cracked the Code", LINE2(0));
        } else if (i == 8 && i != count) {
            --chance;
            DISP_ON_AND_CURSOR_OFF;
            clcd_print(" WRONG PASSWORD ", LINE1(0));
            clcd_print(" ATTEMPT ", LINE2(0));
            clcd_putch('0' + chance, LINE2(10));
            for (unsigned long y = 0xFFFFA; --y;);
            i = 0;
            count = 0;
            delay -= 2500;
            wait = 0;
            once = 1;
        } else if (chance && !i && once) {
            once = 0;
            CLEAR_DISP_SCREEN;
            clcd_print(" ENTER PASSWORD ", LINE1(0));
            LCD_CURSOR_LINE2;
            LCD_CURSOR_BLINK;

        }
        if (!chance && start) {
            start = 0;
            LED1 = 1;
            DISP_ON_AND_CURSOR_OFF;
            CLEAR_DISP_SCREEN;
            clcd_print("   USER WAS    ", LINE1(0));
            clcd_print("    BLOCKED", LINE2(0));
        }
        if (chance < 5 && start) {
            if (wait++ == delay) {
                wait = 0;
                LED1 = !LED1;
            }
        }

    }
}
