/*
Name : Santosh Ramesh Sunagd
Description : A13 - Implement a 4 digit key press counter
Output Requirement:

1. Implement a 4 digit key press counter
2. On every key press counter value should increment by 1.
3. On a long key press (2 seconds), count should reset to zero.

Inputs:

DKS1 (Digital Keypad Switch 1) as Count Input 
DKS1 long press (2 secs) to reset the count 

*/

#include <xc.h>

#include "digital_keypad.h"
#include "ssd_display.h"
#include "ssd_display.h"

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE,TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};


#pragma config WDT = OFF //Watchdog timer disabled

static void init_config(void) 
{
    init_digital_keypad();
    init_ssd_control();
    //Write your initialization code here
}

void main(void) 
{
    init_config(); //Calling initializing function
    unsigned long wait = 0, wait1 = 1;
    unsigned int count = 0;
    unsigned char key;
    while (1) 
    {
       /* Read the Digital keypad */
        key = read_digital_keypad(LEVEL);
        if(key == SWITCH1)
        {
            if(wait1)
           {
                wait1 = 0;
                count++;
           }
            else if(wait++ == 200)
            {
                wait = 0;
                count = 0;
            }
        }
        else
        {
            wait1 = 1;
        }
            ssd[3] = digit[count%10];
            ssd[2] = digit[(count%100)/10];
            ssd[1] = digit[(count%1000)/100];
            ssd[0] = digit[count/1000];
             display(ssd);
       
    }
}
