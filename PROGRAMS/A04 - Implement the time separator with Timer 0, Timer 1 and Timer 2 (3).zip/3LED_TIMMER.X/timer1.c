#include <xc.h>
#include "main.h"

void init_timer1(void)
{
    TMR1ON = 1;
    TMR1CS = 0;
    T1OSCEN = 1;
    T1RUN = 1;
    TMR1 = 3036;
    TMR1IF = 0;
    TMR1IE = 1;
}