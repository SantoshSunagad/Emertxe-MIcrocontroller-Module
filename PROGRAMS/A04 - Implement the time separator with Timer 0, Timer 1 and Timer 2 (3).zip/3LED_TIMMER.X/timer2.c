#include <xc.h>
#include "main.h"

void init_timer2(void)
{
    TMR2ON = 1;
    TMR2IF = 0;
    TMR2IE = 1;
    PR2 = 249;
}