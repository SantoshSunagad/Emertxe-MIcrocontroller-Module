/*
 Name : Santosh Ramesh Sunagad
 Description: A04 - Implement the time separator with Timer 0, Timer 1 and Timer 2
 Output Requirement:

1. All three LEDs assigned to specific timer should toggle at frequency of 0.5 Hz (500 msecs) as soon as the board is powered on or reset.
2. There should be time synchronization between all LEDs on longer runs greater than hours (No drifts in the output should be seen).

Inputs:
-Timer0
-Timer1
-Timer2

 */
#include <xc.h>
#include "timer0.h"
#include "main.h"

void init_config(void)
{
	PEIE = 1;
	/* Clear old content */
	PORTB = 0x00;

	/* Set PORTB as a Output */
	TRISB = 0x00;

	/* Config PORTB as digital */
	ADCON1 = 0x0F;

	init_timer0();
    init_timer1();
    init_timer2();

	GIE = 1;
}


void main(void)
{
	init_config();

	while (1)
	{
		;
	}
}
