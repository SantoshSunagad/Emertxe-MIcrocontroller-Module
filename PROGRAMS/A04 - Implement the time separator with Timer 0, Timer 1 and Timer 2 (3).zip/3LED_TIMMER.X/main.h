#ifndef MAIN_H
#define MAIN_H



/* The name LED1 is based on the legend in eCee Board */
#define LED1				PORTBbits.RB0
#define LED2                PORTBbits.RB1
#define LED3                PORTBbits.RB2
void init_timer1(void);
void init_timer2(void);
#endif