#include <xc.h>
#include "isr.h"

extern unsigned int blink_field=0;
extern unsigned int sec;
extern unsigned int half_sec;

void __interrupt() isr(void) {
    static unsigned short count;

    if (TMR0IF) {
        TMR0 = TMR0 + 8;
        
        if (count++ == 20000) {
            count = 0;
            blink_field = !blink_field;
            sec++;
        }
        if (count == 10000) {
            blink_field = !blink_field;
        }

        TMR0IF = 0;
    }
}