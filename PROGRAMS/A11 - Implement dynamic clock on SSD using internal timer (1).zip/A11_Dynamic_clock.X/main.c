/*
Name : Santosh Ramesh Sunagad
Description : A11 - Implement dynamic clock on SSD using internal timer
Output Requirement:

1. As soon as the board is powered on or reset, the clock should start at 00.00.
2. The decimal point of the hours field (one’s place) should blink every 500 msecs (0.5 Hz).
3. The clock format should be 24Hrs
4. The clock enters into configuration mode by pressing Set / Edit Key.
5. The configuration mode is indicated by a blink on the minute field every 500 msecs
6. The fields can be selected with Choose Field Key, The selected field should blink at the rate of 500 mses indicating the selection
7. The Increment Key could be used to increment and the Decrement Key could be used to decrement the value of selected field, It should be level triggered
8. Once the time is set you may use the Set / Edit Key to start the clock and this mode is called a run mode.
9. No key except Set / Edit key should sensitive in run mode

Inputs:

1. DKS1 (Digital Keypad Switch 1) as Increment key
2. DKS2 (Digital Keypad Switch 2) as  Decrement key
3. DKS3 (Digital Keypad Switch 3) as  Choose Field key
4. DKS4 (Digital Keypad Switch 4) as Set/Edit key
5. Timer
*/

#include <xc.h>
#include "ssd_display.h"
#include "digital_keypad.h"
#include "isr.h"
#include "timer0.h"

/* declare Character array */
static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
/* Global Variables */
unsigned int blink_field = 0, half_sec = 0;
unsigned int hour = 0, minute = 0, sec = 0;
/* Initialization all pheriphrals */
void init_config(void) {
    GIE = 1;
    PEIE = 1;
    init_ssd_control();
    init_digital_keypad();
    init_timer0();
}

void main(void) {
    init_config();
    unsigned char key, Edit_flag = 0, field_flag = 0;

    while (1) {
        key = read_digital_keypad(STATE_CHANGE);
        /* Read the Digital Keypad Switch */
        /* SET or EDIT MODE by Switch4 */
        if (key == SWITCH4) {
            Edit_flag = !Edit_flag;
            field_flag = 0;
            sec = 0;
        }/* Choose the field key by Switch3 */
        else if (Edit_flag && key == SWITCH3) {
            field_flag = !field_flag;
        }/* Decrement key by Switch2 */
        else if (key == SWITCH2) {
            if (Edit_flag && field_flag == 1) {
                --hour;
                if (hour == -1) {
                    hour = 23;
                }
            } else if (Edit_flag && field_flag == 0) {
                --minute;
                if (minute == -1) {
                    minute = 59;
                }
            }
        }/* Increment key by Switch 1 */
        else if (key == SWITCH1 && Edit_flag) {

            if (field_flag == 1) {
                ++hour;
                if (hour == 24) {
                    hour = 0;
                }
            } else if (field_flag == 0) {
                ++minute;
                if (minute == 60) {
                    minute = 0;
                }
            }
        }

        
        /* Choose the Field key  for Blink */
        /* flag bit is 0 for Minute */
        if (Edit_flag && field_flag == 0) {
            if (blink_field) {
                ssd[0] = digit[hour / 10];
                ssd[1] = digit[hour % 10];
                ssd[2] = digit[minute / 10];
                ssd[3] = digit[minute % 10];
            } else {
                ssd[0] = digit[hour / 10];
                ssd[1] = digit[hour % 10];
                /* Blink minute */
                ssd[2] = 0x00;
                ssd[3] = 0x00; 
            }
        }/* flag bit 1 for Hour */
        else if (Edit_flag && field_flag == 1) {
            if (blink_field) {
                ssd[0] = digit[hour / 10];
                ssd[1] = digit[hour % 10];
                ssd[2] = digit[minute / 10];
                ssd[3] = digit[minute % 10];
            } else {
                /* Blink Hour */
                ssd[0] = 0x00;
                ssd[1] = 0x00;
                ssd[2] = digit[minute / 10];
                ssd[3] = digit[minute % 10];
            }

        } /* Clock in Run Mode Operation */ 
        else {
             /* Time calculation */
            if (sec == 60) {
                minute++;
                sec = 0;
            }
            if (minute == 60) {
                hour++;
                minute = 0;
            }
            if (hour == 24) {
                hour = 0;
            }
            /* Blink dp point */
            if (blink_field) {
                ssd[0] = digit[hour / 10];
                ssd[1] = digit[hour % 10] | DOT;
                ssd[2] = digit[minute / 10];
                ssd[3] = digit[minute % 10];
            } else {
                ssd[0] = digit[hour / 10];
                ssd[1] = digit[hour % 10];
                ssd[2] = digit[minute / 10];
                ssd[3] = digit[minute % 10];
            }
        }
        /* Display Function Call */
        display(ssd);
    }
}