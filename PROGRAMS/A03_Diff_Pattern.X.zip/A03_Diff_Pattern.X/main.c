/* Name : Santosh Ramesh Sunagad
 Description: A03 - Implement multiple patterns on LEDs controlled by switches
 Output Requirements:

1. Upon giving the power supply, all 8 LEDs should be OFF.

2. Now, press switch-1 on the Digital Keypad, LEDs should glow according to the pattern-1*

3. Press switch-2, LEDs should glow according to the pattern-2*

4. Press switch-3, LEDs should glow according to the pattern-3*

5.  Press switch-4, LEDs should glow according to the pattern-4*

*pattern-1: The LEDs should glow from Left to Right and Right to left as explained in the assignment-1.
*pattern-2: The LEDs should glow from left to Right and switch off from left to right, no direction control/ direction change.
*pattern-3: The LEDs should blink alternately.
*pattern-4: The LEDs has to blink nibble wise, i.e first 4 LEDs will be ON, next 4 LEDs will be OFF, after first 4 LEDs will be OFF, next 4 LEDs will be ON.
 
 */
#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

#pragma config WDT = OFF // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))

static void init_config(void)
{
    ADCON1 = 0x0F;

    TRISB = 0x00; /* set direction as output */
    PORTB = 0x00; /* initially all led's OFF State  */ 
    init_digital_keypad();
}

void main(void)
{
    /* decalare variables */
    unsigned char key;
    unsigned short i;
    long wait = 0;
    unsigned char pattern1 = 0, pattern2 = 0, pattern3 = 0, pattern4 = 0;
    init_config();

    while (1)
    {
        /* Read Digital keypad Input */
        key = read_digital_keypad(STATE_CHANGE);
        if (key == SWITCH1)
        {
            /* Pattern 1 Enalbe and Remaing are Disable */
            pattern1 = 1;
            pattern2 = 0;
            pattern3 = 0;
            pattern4 = 0;
            PORTB = 0x00;
            i = 0;
        }
        else if (key == SWITCH2)
        {
            /* Pattern 2 Enalbe and Remaing  are Disable */
            pattern1 = 0;
            pattern2 = 1;
            pattern3 = 0;
            pattern4 = 0;
            PORTB = 0x00;
            i = 0;
        }
        else if (key == SWITCH3)
        {
            /* Pattern 3 Enalbe and Remaing  are Disable */
            pattern1 = 0;
            pattern2 = 0;
            pattern3 = 1;
            pattern4 = 0;
            PORTB = 0XAA;
            i = 0;
        }
        else if (key == SWITCH4)
        {
            /* Pattern 4 Enalbe and Remaing  are Disable */
            pattern1 = 0;
            pattern2 = 0;
            pattern3 = 0;
            pattern4 = 1;
            PORTB = 0x0F;
            i = 0;
        }

        /* All Pattern Run According to condition */ 
        if (wait++ == 80000)
        {
            wait = 0;

            /* When SW1 is pressed */
            if (pattern1)
            {
                // 1st pattern
                if (i <= 7) //Left to Right Turn on LED's
                {
                    PORTB = ((PORTB << 1) | 0x01);
                    i++;
                }
                else if (i > 7 && i <= 15) //Left to Right Turn off LED's
                {
                    PORTB = (PORTB << 1);
                    i++;
                }
                else if (i > 15 && i <= 23) //Right to Left Turn on LED's
                {
                    PORTB = ((PORTB >> 1) | 0x80);
                    i++;
                }
                else if (i > 23 && i < 32)  //Right to Left Turn off LED's
                {
                    PORTB = (PORTB >> 1);
                    i++;
                }
                else
                {
                    i = 0;  /* Restart the Pattern */
                }
            }

            /* When SW2 is pressed */
            if (pattern2)
            {
                if (i <= 7) //Left to Right Turn on LED's
                {
                    PORTB = ((PORTB << 1) | 0x01);
                    i++;
                }
                else if (i > 7 && i <= 15) //Left to Right Turn off LED's
                {
                    PORTB = (PORTB << 1);
                    i++;
                }
                else
                {
                    i = 0;
                }
            }
             /* When SW3 is pressed */
            if (pattern3)
            {
                PORTB = ~PORTB;
            }

             /* When SW4 is pressed */
            if (pattern4)
            {
                PORTB = ~PORTB;
            }
        }
    }
}
