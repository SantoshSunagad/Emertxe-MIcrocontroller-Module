/*
Name : Santosh Ramesh Sunagd
Description : A26 - Implement a 4 digit key press counter with persistence
Output Requirements:
- As soon as the board is powered up or reset, counter should display 0000 on SSDs.
- On every key press  counter value should increment by 1.
- On a  long key press (2 seconds), Count should  reset to zero.
- On pressing STORE switch, the current count should be  stored in internal EEPROM.
- On subsequent power ups or reset the counter should start from the previous stored value in the EEPROM.

Inputs:
1. DKS 1 as Count input .
2. DKS 1 Long press to reset the count .
3. DKS 2 Store Input.

*/
#include <xc.h>
#include "digital_keypad.h"
#include "main.h"
#include "ssd_display.h"
#include "eeprom.h"

#pragma config WDT = OFF //Watchdog timer disabled

static unsigned char ssd[MAX_SSD_CNT];
static unsigned char digit[] = {ZERO, ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};
unsigned int count = 0, temp=0;

static void init_config(void) {
    //Write your initialization code here
    init_digital_keypad();
    init_ssd_control();
    /* Read from EEPROM Memory */
    count = (100 * read_internal_eeprom(0x00)) + read_internal_eeprom(0x01);
}

void main(void) {
    init_config(); //Calling initializing function
    unsigned char key, flag = 1, flag2 = 1;
    unsigned int wait = 0;
    while (1) {
        //Write application codehere
        key = read_digital_keypad(LEVEL);
        if (key == SWITCH1) {
            if (flag) {
                flag = 0;
                count++;
                wait = 0;
            }
            if (wait++ == 100) {
                wait = 0;
                count = 0;
            }
        } else {
            flag = 1;
        }
        if (key == SWITCH2) {
            if (flag2) {
                flag2 = 0;
                /* write in EEPROM Memory */
                write_internal_eeprom(0x00, (count / 100));
                write_internal_eeprom(0x01, (count % 100));
            }
        } else {
            flag2 = 1;
        }
        ssd[0] = digit[count / 1000];
        ssd[1] = digit[(count / 100) % 10];
        ssd[2] = digit[(count / 10) % 10];
        ssd[3] = digit[count % 10];
        display(ssd);   /* Function Call Display */
    }
}
