/*
Name : Santosh Ramesh Sunagad
Decription : A20 - Implement a right scrolling message marquee
Output Requirements:

1. As soon as the board is powered up or reset, a static message (hardcoded) should start scrolling from left to right CLCD. 
2. The scroll should repeat indefinitely. 
3. The scroll frequency should be 0.5Hz (Approximately, Non Timer Based).

Inputs:

1. Static message in embedded code

*/
#include <xc.h>
#include "clcd.h"
/*Initialization Function Definition */
static void init_config(void) {
    init_clcd();
}

void main(void) {
    /* declare Variables */
    unsigned char temp;
    unsigned int wait = 700, i = 17;
    /* Right scrolling Message */
    char msg[] = " SANTOSH SUNAGAD ";   

    init_config();

    while (1) {
        /* Constant Message */
        clcd_print(" EMERTXE 23020D ", LINE1(0));
        /* declare last character in temp*/
        temp = msg[17];

        if (i > 0) {
            /* One by one character Right Shift */
            msg[i] = msg[i - 1];
            i--;
        } else {
            /* temp character is store 0th index*/
            msg[0] = temp;
            /* Non Blocking delay */
            if (--wait) {
                clcd_print(msg, LINE2(0));
            } else {
                wait = 700;
                i = 17;
            }
        }
    }
}
