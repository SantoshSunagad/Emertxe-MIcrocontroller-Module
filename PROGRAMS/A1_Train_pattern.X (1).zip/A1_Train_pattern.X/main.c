/*
 Name : Santosh Ramesh Sunagad
 Description: A01-Implement LED train pattern on leds
 */
#include <xc.h>

#pragma config WDT = OFF //Watchdog timer disabled

static void init_config(void) {
    //Write your initialization code here
    TRISB=0x00;     //set Direction RB0-RB7 as Output
    PORTB=0x00;     //Initially all 8 Led's are Turn Off
}

void main(void) {
    init_config(); //Calling initializing function
    unsigned short i;
    long wait=0;
    
    while(1)
    {
        if(wait++ == 100000)
        {
            wait=0;
             if (i <= 7) //Left to Right Turn on LED's
                {
                    PORTB = ((PORTB << 1) | 0x01);
                    i++;
                }
                else if (i > 7 && i <= 15) //Left to Right Turn off LED's
                {
                    PORTB = (PORTB << 1);
                    i++;
                }
                else if (i > 15 && i <= 23) //Right to Left Turn on LED's
                {
                    PORTB = ((PORTB >> 1) | 0x80);
                    i++;
                }
                else if (i > 23 && i < 32)  //Right to Left Turn off LED's
                {
                    PORTB = (PORTB >> 1);
                    i++;
                }
                else
                {
                    i = 0;
                }
        }
    }
}
